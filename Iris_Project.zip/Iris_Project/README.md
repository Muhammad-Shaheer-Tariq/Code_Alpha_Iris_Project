# Iris Classification Project

A machine learning project that classifies iris flower species using the classic Iris dataset.

## Overview

This project focuses on building a machine learning model to classify Iris flower species — Setosa, Versicolor, and Virginica — based on their sepal and petal measurements.  
The Iris dataset is one of the most popular datasets in machine learning and is included in the Scikit-learn library.  

In this project:
- The Iris dataset is loaded using Scikit-learn.
- A classification model is trained using features like sepal length, sepal width, petal length, and petal width.
- The trained model predicts the species of an Iris flower based on its measurements.
- Model performance is evaluated using accuracy and test data results.
- This project helps understand basic machine learning classification concepts.

## Dataset

The project uses the famous Iris dataset, which is available directly from the Scikit-learn library.  
It contains measurements of 150 Iris flowers across three species: Setosa, Versicolor, and Virginica.

**Dataset details:**
- **Total samples:** 150  
- **Features (measurements):**  
  - Sepal Length  
  - Sepal Width  
  - Petal Length  
  - Petal Width  
- **Number of classes:** 3  

## Installation

To run this project, make sure you have Python installed (version 3.8 or above recommended).

Follow these steps:

### 1. Create a virtual environment (optional but recommended)

bash
python -m venv env

* Windows
env\Scripts\activate

* Mac Linux
source env/bin/activate

liabraries required

pip install scikit-learn pandas numpy matplotlib seaborn

### How To Run.

## Usage

You can run this project easily using Jupyter Notebook 

### 1. Open the Jupyter Notebook
If your work is in a `.ipynb` file, start Jupyter Notebook:

bash
jupyter notebook

Code_alpha_Iris_project.ipynb

2. Run all cells

Execute the notebook cells in order to:

1.Load the Iris dataset

2.Train the machine learning model

3.Test the model

4.Visualize results





## Conclusion

This Iris Classification project demonstrates the complete workflow of a basic machine learning classification task.  
By using the Iris dataset and Scikit-learn, the project shows how to:

- Load and explore a real-world dataset  
- Train a classification model  
- Evaluate model accuracy and performance  
- Make predictions using new input data  

The project is ideal for beginners learning machine learning fundamentals, data preprocessing, and model evaluation.  
It provides a solid foundation for exploring more advanced machine learning algorithms and larger datasets.








